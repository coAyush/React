import React from 'react'
import Header from '../components/Header'
import Clock from '../components/Clock'

const Todo = () => {
  return (
    <>
    <div className='flex flex-col bg-blue-950 min-h-screen gap-2.5'>
      <Header/>
      <Clock/>
    </div>
    </>
  )
}

export default Todo
